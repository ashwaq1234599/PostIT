export const UserData=[
    {
        name:"Ahmed",
        email:"ah123@gmail.com",
        password:"12365"
    },
    {
        name:"Sara",
        email:"sare3@gmail.com",
        password:"76543"
    },
];