import {it,expect,describe} from 'vitest';

describe("main",()=>{
    it("Should result be pass",()=>{
        expect(1).toBeTruthy();    })
})