const Departments = () => {
  return <div>Departments</div>;
};

export default Departments;
